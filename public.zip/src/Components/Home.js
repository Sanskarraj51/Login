import React from "react";

function Home() {
  return (
    <>
      <h1>Login Successfully</h1>
    </>
  );
}

export default Home;
